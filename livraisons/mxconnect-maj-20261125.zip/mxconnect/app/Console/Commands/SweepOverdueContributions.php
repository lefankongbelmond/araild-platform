<?php

namespace App\Console\Commands;

use App\Models\Central\Mutual;
use App\Models\Tenant\ContributionSchedule;
use Illuminate\Console\Command;

/**
 * Daily arrears sweep (CDC §13). For every approved mutual, marks schedules
 * whose due date has passed and are still unpaid as 'overdue'. Tenant-aware:
 * each mutual is processed inside its own database.
 */
class SweepOverdueContributions extends Command
{
    protected $signature = 'contributions:sweep-overdue';
    protected $description = 'Mark unpaid, past-due contribution schedules as overdue (per tenant).';

    public function handle(): int
    {
        $total = 0;

        Mutual::where('status', 'approved')->each(function (Mutual $mutual) use (&$total) {
            $mutual->run(function () use (&$total) {   // stancl: run closure inside tenant context
                // Changements de formule validés dont la date d'effet est atteinte (2026-11-23).
                if (\Illuminate\Support\Facades\Schema::hasTable('formula_migrations')) {
                    app(\App\Services\Tenant\FormulaMigrationService::class)->applyDue();
                }
                // Échéanciers glissants (2026-11-06) + échéances dépassées marquées en retard.
                $r = app(\App\Services\ScheduleGenerationService::class)->refreshAll();
                $total += $r['overdue'];
            });
        });

        $this->info("Marked {$total} schedule(s) overdue.");
        return self::SUCCESS;
    }
}
